run `pip install -r requirements.txt` to install the requirements

Replace `python3` with `python` for windows

Q1: `python3 mdirectory.py`
Inputs: data.csv
Outputs: TUI
This will open up a TUI. Use the search bar at the top to search, and press the buttons to insert/update/delete.

Q2: `manim -pqm map.py`
Inputs: map.txt
Outputs: Will play the animation in your default video player
This will open up your default video player, with the path animated and required values displayed.

Q3: `python3 kaooa.py`
Inputs: -
Outputs: This will open up a window, where you can use your mouse to play the game.